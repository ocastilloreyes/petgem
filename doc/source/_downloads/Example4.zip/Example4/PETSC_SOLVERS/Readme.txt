Example 3: Use of PETSc solvers
===============================

In PETGEM, PETSc options are accessible via the petsc.opts file. This
example include a short list of relevant configuration options for the
solution of the problem under consideration.

Solver scripts
--------------

* Direct solver by MUMPS: ex1_petsc.opts

* GMRES with SOR: ex2_petsc.opts

* GMRES with GAMG: ex3_petsc.opts

* GMRES with ASM: ex4_petsc.opts

* GMRES with Jacobi: ex5_petsc.opts

* TFQMR with SOR: ex6_petsc.opts

Running
-------

For the use of this scripts invoke PETGEM as follows:

mpirun -n 4 python3 kernel.py -options_file DIPOLE1D/ex#_petsc.opts DIPOLE1D/modelParams.py

where ex#_petsc.opts is the file selected from the previous list


Documentation
--------------

-  http://petgem.bsc.es

-  http://pypi.python.org/pypi/petgem/

-  https://github.com/ocastilloreyes/petgem
