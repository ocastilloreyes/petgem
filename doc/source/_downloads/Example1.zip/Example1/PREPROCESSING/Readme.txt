Example 1: Pre-processing data for PETGEM
=========================================

This is a simple case of PETGEM pre-processing. The computational domain
is composed by two layers [sediments, water] with its corresponding
conductivity values [1.0, 1.0/0.3] S/m. The Nédélec element order is
p=1 (first order)

The modelling consist of 35 receivers whose spatial positions are
included in the Input_preprocessing/RECEIVER_POSITIONS.txt file. The
Input_preprocessing/PREPROCESSING.msh is the mesh file (Gmsh) for this example.


Pre-processing
--------------

For pre-processing stage run:

python3 run_preprocessing.py PREPROCESSING/preprocessingParams.py


Documentation
--------------

-  http://petgem.bsc.es

-  http://pypi.python.org/pypi/petgem/

-  https://github.com/ocastilloreyes/petgem
