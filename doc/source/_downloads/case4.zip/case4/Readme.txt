Example 4: 3D trapezoidal hill model
====================================

This is a simple 3D MT survey using PETGEM. The test under consideration is a
based on the 3D trapezoidal hill model described in

Nam, M.J., Kim, H.J., Song, Y., Lee, T.J., Son, J.S., Suh, J.H., 2007. 3D magnetotelluric modelling including
surface topography. Geophysical Prospecting 55, 277–287.

The domain is composed by two layers [air, Earth] with its corresponding
conductivity values [1.0/1e9, 1.0/100.0] S/m. The Nédélec element order
is p=2 (second order)

The modelling consist of 41 stations whose spatial positions are
included in the receiver_pos.h5 file. The HILL_TRAPEZOIDAL.geo is the mesh file (Gmsh) for this example.

Running
-------

For the solution of the modelling using 4 MPI tasks, run:

mpirun -n 4 python3 kernel.py -options_file examples/case4/petsc.opts examples/case4/params.yaml


Documentation
--------------

-  https://petgem.bsc.es

-  https://pypi.python.org/pypi/petgem/

-  https://github.com/ocastilloreyes/petgem
