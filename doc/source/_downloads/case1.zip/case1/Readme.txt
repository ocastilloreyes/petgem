Example 1: Canonical model of an off-shore hydrocarbon reservoir
================================================================

This is a simple 3D CSEM survey using PETGEM. The domain is composed
by four layers [sediments, oil, sediments, water] with its corresponding
conductivity values [1.0, 1.0/100.0, 1.0, 1.0/0.3] S/m. The Nédélec element order
is p=1 (first order)

The modelling consist of 58 receivers whose spatial positions are
included in the receiver_pos.h5 file. The DIPOLE1D.geo is the mesh file (Gmsh) for this example.

Running
-------

For the solution of the modelling using 4 MPI tasks, run:

mpirun -n 4 python3 kernel.py -options_file examples/case1/petsc.opts examples/case1/params.yaml


Documentation
--------------

-  https://petgem.bsc.es

-  https://pypi.python.org/pypi/petgem/

-  https://github.com/ocastilloreyes/petgem
