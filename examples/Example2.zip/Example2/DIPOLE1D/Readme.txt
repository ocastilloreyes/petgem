Example 2: Canonical model of an off-shore hydrocarbon reservoir
================================================================

This is a simple 3D CSEM survey using PETGEM. The domain is composed
by four layers [sediments, oil, sediments, water] with its corresponding
conductivity values [1.0, 1.0/100.0, 1.0, 1.0/0.3] S/m.

The modelling consist of 48 receivers whose spatial positions are
included in the Input_preprocessing/RECEIVER_POSITIONS.txt file. The
Input_preprocessing/DIPOLE1D.msh is the mesh file (Gmsh) for this example.

Pre-processing
--------------

For pre-processing stage run:

python3 run_preprocessing.py DIPOLE1D/preprocessingParams.py

Running
-------

For the solution of the modelling using 4 MPI tasks, run:

mpirun -n 4 python3 kernel.py -options_file DIPOLE1D/petsc.opts DIPOLE1D/modelParams.py


Documentation
--------------

-  http://petgem.bsc.es

-  http://pypi.python.org/pypi/petgem/
