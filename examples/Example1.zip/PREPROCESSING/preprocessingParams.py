''' Parameters file template for **PETGEM** preprocessing.

For preprocessing task, a mesh file, conductivity model and
receivers file are mandatory.

In order to avoid a specific parser, this file is imported by
**PETGEM** as a Python dictionary. As consequence, the dictionary
name and his key names MUST NOT BE changed.

All file paths should consider as absolute.
'''
preprocessing = {
    # ---------- Mesh file ----------
    'MESH_FILE': 'PREPROCESSING/Input_preprocessing/PREPROCESSING.msh',

    # ---------- Material conductivities ----------
    'MATERIAL_CONDUCTIVITIES': [1., 1./.3],

    # ---------- Receivers position file ----------
    'RECEIVERS_FILE': 'PREPROCESSING/Input_preprocessing/RECEIVER_POSITIONS.txt',

    # ---------- Path for Output ----------
    'OUT_DIR': 'PREPROCESSING/Input_model/',

}
